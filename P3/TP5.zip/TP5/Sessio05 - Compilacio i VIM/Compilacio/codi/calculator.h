 

double euclideanDistance(int x1, int y1, int x2, int y2);//calculates the euclidean distance between points (x1,y1) and (x2,y2)

double manhattanDistance(int x1, int y1, int x2, int y2);//calculates the manhattan distance between points (x1,y1) and (x2,y2)

